var i = 0;
const addInput = document.getElementById("addInput");
const addBtn = document.getElementById("addBtn");
const read = document.getElementById("read");
const blank = document.getElementById("blank");

const today = document.getElementById("today");
const tomorrow = document.getElementById("tomorrow");

const inputbox = document.getElementsByClassName("inputbox");
for (let j = 0; j < inputbox.length; j++) {
  inputbox[j].addEventListener("change", () => {
    let data = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(data));

    //   sessionStorage.setItem(data, ev.target.id);
    sessionStorage.setItem(data, [ev.target.id, $("#" + data).text()]);
  });
}

addBtn.addEventListener("click", () => {
  makedragTarget(addInput.value);
});
function makedragTarget(data) {
  $("#blank").append(
    `<p id=e` +
      i++ +
      ` class="inputbox" draggable="true" ondragstart="drag(event)" contentEditable>` +
      data +
      `</p>`
  );
}

function allowDrop(ev) {
  ev.preventDefault();
}

function drag(ev) {
  ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
  ev.preventDefault();
  let data = ev.dataTransfer.getData("text");
  ev.target.appendChild(document.getElementById(data));

  //   sessionStorage.setItem(data, ev.target.id);
  sessionStorage.setItem(data, [ev.target.id, $("#" + data).text()]);
}

read.addEventListener("click", () => {
  for (var i = 0; i < sessionStorage.length; i++) {
    let key = sessionStorage.key(i);
    let value = sessionStorage.getItem(sessionStorage.key(i));
    if (value != "true") {
      console.log(key, " ", value);
      let temp = value.split(",");
      let place = temp[0];
      let daa = temp[1];
      // let imgNode = document.getElementById(key);
      // let temm =
      // `<p id=e` +
      // key +
      // ` class="inputbox" draggable="true" ondragstart="drag(event)" contentEditable>` +
      // temp[1] +
      // `</p>`;
      // console.log(typeof temm);
      // document.getElementById(place).append(temm);

      $("#" + place).append(
        `<p id=e` +
          key +
          ` class="inputbox" draggable="true" ondragstart="drag(event)" contentEditable>` +
          daa +
          `</p>`
      );
    }
  }
});
