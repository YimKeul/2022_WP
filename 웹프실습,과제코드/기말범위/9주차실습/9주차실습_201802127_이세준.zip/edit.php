<?php
    session_start();
    $name  =$_POST['name'];
    $grade  =$_POST['grade'];
    echo $name." 의 학년을 ".$grade."학년으로 변경하였습니다."."<br>";

    $DBIndex = array($name,$grade);
    if (!isset($_SESSION['Test'])) {
        $_SESSION['Test'] = array();
    }

    echo "변경전 데이터";
    echo "<br>";
    var_dump($_SESSION); //확인
    // array_push($_SESSION['Test'],$DBIndex);
    for ($i = 0 ; $i<count($_SESSION['Test']);$i++){
        if(strcmp($name, $_SESSION['Test'][$i][0])==0){
            $_SESSION['Test'][$i][1] = $grade;
        }
    }
    echo "<br>";
    echo "변경후 데이터";
    echo "<br>";
    var_dump($_SESSION); //확인




?>