<?php
    session_start();
    $name  =$_POST['name'];
    $grade  =$_POST['grade'];



    $DBIndex = array($name,$grade);
    if (!isset($_SESSION['Test'])) {
        $_SESSION['Test'] = array();
    }

    echo "변경전 데이터";
    echo "<br>";
    var_dump($_SESSION); //확인
    echo "<br>";

    $result = array();
    if($name == null){
        for ($i = 0 ; $i<count($_SESSION['Test']);$i++){
            if( $grade ==  $_SESSION['Test'][$i][1]){
                echo $_SESSION['Test'][$i][0]."을 삭제했습니다."."<br>";
            }else{
                array_push($result,array($_SESSION['Test'][$i][0],$_SESSION['Test'][$i][1]));
            }
        }        

    }else{
        for ($i = 0 ; $i<count($_SESSION['Test']);$i++){
            if( ($grade ==  $_SESSION['Test'][$i][1]) && (strpos($_SESSION['Test'][$i][0],$name))!== false){
                echo $_SESSION['Test'][$i][0]."을 삭제했습니다."."<br>";
                
            }else{
                array_push($result,array($_SESSION['Test'][$i][0],$_SESSION['Test'][$i][1]));
            }
        }   
    }
    $_SESSION['Test'] = $result;


    echo "<br>";
    echo "변경후 데이터";
    echo "<br>";
    var_dump($_SESSION); //확인




?>