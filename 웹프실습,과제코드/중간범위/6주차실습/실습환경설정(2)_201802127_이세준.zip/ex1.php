<!DOCTYPE html>
<html>
<body>
 <?php
    echo "201802127 이세준"."<br>";
    echo "실습완료"; 
    ?> 
</body>
</html>