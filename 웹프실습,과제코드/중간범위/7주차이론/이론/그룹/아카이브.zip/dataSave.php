<!DOCTYPE html>
<html>
  <head></head>
  <body>
    <p>저장되었습니다.</p>
    <?php
        $myfile = fopen("data.txt", "a") or die("Unable to open file!");
        $name =$_GET["name"];
        $hei = $_GET["height"];
        $enter = "\n";
        fwrite($myfile, $name);
        fwrite($myfile,"|");
        fwrite($myfile, $hei);
        fwrite($myfile,
         $enter);
        fclose($myfile);    
    ?> 

  </body>
</html>